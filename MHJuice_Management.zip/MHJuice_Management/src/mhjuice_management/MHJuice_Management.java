/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mhjuice_management;

/**
 *
 * @author asus
 */
public class MHJuice_Management {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frm_login frm = new frm_login();
        frm.setVisible(true);
    }
    
}
